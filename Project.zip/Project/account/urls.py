from django.urls import path, require
from . import views 
app_name = 'account'

url_patterns = [
    path('login/', views.login, name='login'),
    path('logout/', views.logout, name='logout'),
    path('register/', views.register, name='register'),
    path('update/', views.update, name='update')
]